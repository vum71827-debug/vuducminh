const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const TILE = 48;
const ROWS = 10;
const COLS = 10;
let score = 0;
const map = [
  [1,1,1,1,1,1,1,1,1,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,0,3,0,0,0,0,2,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,0,0,0,3,0,0,0,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,0,0,0,0,0,0,0,0,1],
  [1,1,1,1,1,1,1,1,1,1]
];
let boxes = [
  {x:2,y:2},
  {x:6,y:2},
  {x:4,y:5}
];
let player = {x:5,y:6};
function drawGrid(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  for(let r=0;r<ROWS;r++){
    for(let c=0;c<COLS;c++){
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(c*TILE, r*TILE, TILE, TILE);
      ctx.strokeStyle = '#e6e6e6';
      ctx.lineWidth = 1;
      ctx.strokeRect(c*TILE, r*TILE, TILE, TILE);
    }
  }
}
function drawScene(){
  drawGrid();
  for(let r=0;r<ROWS;r++){
    for(let c=0;c<COLS;c++){
      if(map[r][c]===1){
        ctx.fillStyle = '#e5cfa8';
        ctx.fillRect(c*TILE, r*TILE, TILE, TILE);
        ctx.strokeStyle = '#d4b88f';
        ctx.strokeRect(c*TILE+1, r*TILE+1, TILE-2, TILE-2);
      } else if(map[r][c]===3){
        ctx.fillStyle = '#158024';
        ctx.fillRect(c*TILE+8, r*TILE+8, TILE-16, TILE-16);
      }
    }
  }
  boxes.forEach(b => {
    ctx.fillStyle = '#c08a2b';
    ctx.fillRect(b.x*TILE+6, b.y*TILE+6, TILE-12, TILE-12);
    ctx.strokeStyle = '#a26f21';
    ctx.strokeRect(b.x*TILE+6, b.y*TILE+6, TILE-12, TILE-12);
  });
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  ctx.arc(player.x*TILE + TILE/2, player.y*TILE + TILE/2, TILE*0.25, 0, Math.PI*2);
  ctx.fill();
}
function isBoxAt(x,y){
  return boxes.some(b=>b.x===x && b.y===y);
}
function move(dx,dy){
  const nx = player.x + dx;
  const ny = player.y + dy;
  if(map[ny][nx]===1) return;
  if(isBoxAt(nx,ny)){
    const bx = nx + dx;
    const by = ny + dy;
    if(map[by] && map[by][bx] !== 1 && !isBoxAt(bx,by)){
      boxes = boxes.map(b => (b.x===nx && b.y===ny) ? {x:bx,y:by} : b);
      player.x = nx; player.y = ny;
    } else return;
  } else {
    player.x = nx; player.y = ny;
  }
  drawScene();
}
document.addEventListener('keydown', e=>{
  if(e.key==='ArrowUp') move(0,-1);
  else if(e.key==='ArrowDown') move(0,1);
  else if(e.key==='ArrowLeft') move(-1,0);
  else if(e.key==='ArrowRight') move(1,0);
});
drawScene();
